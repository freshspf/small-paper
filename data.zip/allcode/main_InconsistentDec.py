import os
import time
import re
from LLM_InconsistentDec import AxiomAnalyzer

def read_cs_units(file_path):
    cs_units = []
    current_unit = []
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            line = line.strip()
            if line.startswith('MIPS <'):
                if current_unit:
                    cs_units.append('\n'.join(current_unit))
                    current_unit = []

                header = re.split(r'[:：]', line, 1)[0].strip()
                current_unit.append(header.strip())
            else:
                current_unit.append(line)
        if current_unit:
            cs_units.append('\n'.join(current_unit))
    return cs_units

# pattern1_file_path = [
#     "./data/negative_exps/mips_pattern1_false.txt",  # negative_exps
#     "./data/no_red_pos_exps/mips_pattern1_real.txt",  # no_red_pos_exps
#     "./data/with_red_pos_exps/mips_pattern1_redundant.txt"  # with_red_pos_exps
# ]
# pattern2_file_path = [
#     "./data/negative_exps/mips_pattern2_neg.txt",  # negative_exps
#     "./data/no_red_pos_exps/mips_pattern2.txt",  # no_red_pos_exps
# ]
pattern3_file_path = [
    "./data/negative_exps/mips_pattern3_neg.txt",  # negative_exps
    "./data/no_red_pos_exps/mips_pattern3.txt",  # no_red_pos_exps
]
# pattern4_file_path = [
#     "./data/negative_exps/mips_pattern4_false.txt",  # negative_exps
#     "./data/no_red_pos_exps/mips_pattern4_real.txt",  # no_red_pos_exps
#     "./data/with_red_pos_exps/mips_pattern4_redundant.txt"  # with_red_pos_exps
# ]
# pattern5_file_path = [
#     "./data/negative_exps/mips_pattern5_false.txt",  # negative_exps
#     "./data/no_red_pos_exps/mips_pattern5_real.txt",  # no_red_pos_exps
#     "./data/with_red_pos_exps/mips_pattern5_redundant.txt"  # with_red_pos_exps
# ]
pattern7_file_path = [
    "./data/negative_exps/mis_pattern2_neg.txt",  # negative_exps
    "./data/no_red_pos_exps/mis_pattern2_pos.txt",  # no_red_pos_exps
]
# pattern8_file_path = [
#     "./data/negative_exps/mis_pattern3_neg.txt",  # negative_exps
#     "./data/no_red_pos_exps/mis_pattern3_pos.txt",  # no_red_pos_exps
# ]
# pattern10_file_path = [
#     "./data/negative_exps/mis_pattern10_false.txt",  # negative_exps
#     "./data/no_red_pos_exps/mis_pattern10_real.txt",  # no_red_pos_exps
#     "./data/with_red_pos_exps/mis_pattern10_redundant.txt"  # with_red_pos_exps
# ]


def main():
    for i in range(2):
        truth_file_path = pattern3_file_path[i]


        file_name = truth_file_path.split("/")[-1]

        file_name_without_extention = file_name[:-4]
        label_file_name = f"{file_name[:-4]}_pred_labels.txt"

        model = AxiomAnalyzer()


        batches = read_cs_units(truth_file_path)
        count = 0

        for batch in batches:
            count += 1
            print(f"==============The current response is returned for the {count} unit.==============")
            print(f"The current ontology is ：{batch}")

            batch = "here are a given axiom set: \n" + batch
            res = model.llm(batch)

            # model_name = "claude-3-7"
            # model_name = "grok-3"
            # model_name = "gpt-4o"
            # model_name = "DeepSeek-R1"
            # model_name = "llama-3.3"

            # model_name = "DeepSeek-V3"
            # model_name = "Doubao-1.5"
            # model_name = "ERNIE-4.0"
            # model_name = "gemini-2.5"
            model_name = "qwq-32b"


            # task = "prompt1"
            task = "prompt2"
            # task = "prompt3"

            if not os.path.exists(f"./output/InconsistencyDetect/{model_name}/{task}/"):
                os.makedirs(f"./output/InconsistencyDetect/{model_name}/{task}/")

            with open(f"./output/InconsistencyDetect/{model_name}/{task}/{file_name_without_extention}_pred_result.txt", "a", encoding="utf-8") as f:
                f.write(f"===================================Response for the {count} unit===================================\n")
                f.write(str(res))
                f.write("\n")
                f.write("\n")
            print(f"CS<{count}> Response：{res}")

            with open(f"./output/InconsistencyDetect/{model_name}/{task}/{label_file_name}", "a", encoding="utf-8") as f:
                f.write(f"CS <{count}>")
                eval_res = model.eval_process(res)
                f.write(eval_res)
                f.write("\n")
            time.sleep(1)


if __name__ == "__main__":
    main()
