** Run Class： ConflictPositiveRedundant, to generate a positive sample with at most @axNum axioms based on an ontology. In this Class, the following parameters need to be configured:

// Set true if the ontology is inconsistent, false otherwise.
boolean dealwithInconsistent = false; 

// The name of the ontology to be considered
String ontoName = "buggyPolicy";

// The path of the ontology
String ontoPath = "file:onto/"+ontoName+".owl"; 

// The maximal number of axioms to be generated for a positive sample with redundant axioms
int axNum = 15;  

** Before running the Class, the following libraries need to be imported to your Java project where the Class above is included:  Pellet libraries and Radon jar file