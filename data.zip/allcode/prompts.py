class Prompt:
    mips_pattern5_real = """
    TASK DESCRIPTION:
  You are tasked with acting as an inconsistency detector. Using the provided MIPS pattern and common reasoning rules, determine whether the following axiom set is inconsistent. Provide a step-by-step explanation for your reasoning regarding consistency or inconsistency.

    TASK REQUIREMENTS:
    Analyze the given axiom set to determine if there is any inconsistency, and provide a detailed explanation of each step in the reasoning process.
    
        PATTERN DEFINITION:
    - PATTERN 2:
  [0] SubClassOf(<X> ObjectSomeValuesFrom(<r> <Y>))
  [1] SubClassOf(<X> ObjectAllValuesFrom(<r> <Z>))
  [2] DisjointClasses(<Y> <Z>)
  
    Sample answer format:
    (··· your detailed explanations here ··· )
    Conclusion:
    The axioms lead to a logical inconsistency
    """

    mips_pattern2_real = """
    TASK DESCRIPTION:
    You are tasked with acting as an inconsistency detector. Using the provided MIPS pattern and common reasoning rules, determine whether the following axiom set is inconsistent. Provide a step-by-step explanation for your reasoning regarding consistency or inconsistency.
    PATTERN DEFINITION:
    - PATTERN 2:
      [0] SubClassOf(<X> ObjectSomeValuesFrom(<r> <Y>))
      [1] SubClassOf(<X> ObjectAllValuesFrom(<r> <Z>))
      [2] DisjointClasses(<Y> <Z>)

        TASK REQUIREMENTS:
        Analyze the given axiom set to determine if there is any inconsistency, and provide a detailed explanation of each step in the reasoning process.

        Sample answer format:
        (··· your detailed explanations here ··· )
        Conclusion:
        The axioms lead to a logical inconsistency
        """

    mips_pattern3_real = """
    TASK DESCRIPTION:
    You are tasked with acting as an inconsistency detector. Using the provided MIPS pattern and common reasoning rules, determine whether the following axiom set is inconsistent. Provide a step-by-step explanation for your reasoning regarding consistency or inconsistency.
    PATTERN DEFINITION:
    - PATTERN 3:
  [0] SubClassOf(<X> ObjectSomeValuesFrom(<r> <Y>))
  [1] SubClassOf(<Y> <nothing>)

        TASK REQUIREMENTS:
        Analyze the given axiom set to determine if there is any inconsistency, and provide a detailed explanation of each step in the reasoning process.

        Sample answer format:
        (··· your detailed explanations here ··· )
        Conclusion:
        The axioms lead to a logical inconsistency
        """

    mis_pattern7_real = """
         TASK DESCRIPTION:
    You are tasked with acting as an inconsistency detector, where an ontology is deemed inconsistent if and only if no model exists that satisfies all of its axioms. In other words, if an assertion about an individual in the ontology cannot be satisfied, it will lead to inconsistency within the ontology. Using the provided MIS patterns, determine whether the following axiom set is inconsistent. Provide a step-by-step explanation for your reasoning regarding consistency or inconsistency.        
    ---
    PATTERN DEFINITION:
    - MIS PATTERNS:
    Pattern 1:
    [0] ObjectPropertyAssertion(<r> <a> <b>)
    [1] FunctionalObjectProperty(<r>)
    [2] ObjectPropertyAssertion(<r> <a> <c>)
    [3] DifferentIndividuals(<b> <c> )
    Pattern 2:
    [0] ObjectPropertyAssertion(<r> <b> <a>)
    [1] InverseFunctionalObjectProperty(<r>)
    [2] ObjectPropertyAssertion(<r> <c> <a>)
    [3] DifferentIndividuals(<b> <c> )
    Pattern 3:
    [0] SubClassOf( <A> DataMaxCardinality(1 <r> rdfs:Literal))
    [1] DataPropertyAssertion(<r> <B> "a"^^xsd: string)
    [2] DataPropertyAssertion(<r> <B> "b"^^xsd: string) 
    These patterns represent some potential forms of logical inconsistency.
    ---
    TASK REQUIREMENTS:
    Analyze the given axiom set to determine if there is any inconsistency, and provide a detailed explanation of each step in the reasoning process.
    ---
    Sample answer format:
    (··· your detailed explanations here ··· )
    Conclusion:
    The axioms lead to a logical inconsistency
           """

    mis_pattern8_real = """
     TASK DESCRIPTION:
    You are tasked with acting as an inconsistency detector, where an ontology is deemed inconsistent if and only if no model exists that satisfies all of its axioms. In other words, if an assertion about an individual in the ontology cannot be satisfied, it will lead to inconsistency within the ontology. Using the provided MIS pattern, determine whether the following axiom set is inconsistent. Provide a step-by-step explanation for your reasoning regarding consistency or inconsistency.

PATTERN DEFINITION:
  [1] ObjectPropertyDomain(<r> <nothing>) 
  [2] ObjectPropertyAssertion(<r> <a > <b>)

  This pattern represents a potential form of logical inconsistency.
---

TASK REQUIREMENTS:
Analyze the axiom set using the above pattern and reasoning rules to determine if there is any inconsistency. Provide a detailed explanation of each step in your reasoning process.
       """


    mis_pattern10_real = """
 TASK DESCRIPTION:
    You are tasked with acting as an inconsistency detector. Using the provided MIS pattern and common reasoning rules, determine whether the following axiom set is inconsistent. Provide a step-by-step explanation for your reasoning regarding consistency or inconsistency.
    ---
    PATTERN DEFINITION:
    - PATTERN 10:
      [0] DisjointClasses(<X> <Y>)
      [1] ClassAssertion(<X> <c1>)
      [2] ClassAssertion(<Y> <c1>)
      This pattern represents a potential form of logical inconsistency.

TASK REQUIREMENTS:
Analyze the given axiom set to determine if there is any inconsistency, and provide a detailed explanation of each step in the reasoning process.

Sample answer format:
(··· your detailed explanations here ··· )
Conclusion:
The axioms lead to a logical inconsistency
   """

    @staticmethod
    def mips_p5_real():
        return Prompt.mips_pattern5_real

    @staticmethod
    def mips_p2_real():
        return Prompt.mips_pattern2_real

    @staticmethod
    def mips_p3_real():
        return Prompt.mips_pattern3_real

    @staticmethod
    def mis_p10_real():
        return Prompt.mis_pattern10_real

    @staticmethod
    def mis_p7_real():
        return Prompt.mis_pattern7_real

    @staticmethod
    def mis_p8_real():
        return Prompt.mis_pattern8_real
