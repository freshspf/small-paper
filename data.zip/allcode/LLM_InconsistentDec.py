# coding=utf-8
from openai import OpenAI
from prompts import Prompt

class AxiomAnalyzer:
    def __init__(self):


        self.client = OpenAI(
            api_key="your-api-key",
            base_url="your-base-url"

        )

        self.client_pre = OpenAI(
            api_key="your-api-key",
            base_url="your-base-url"
        )

        self.temperature = 0.0
        self.max_tokens = 4096

    def llm(self, content):
        """
        调用LLM模型进行处理
        :param content: 需要处理的内容
        :return: 模型的响应内容
        """
        response = self.client_pre.chat.completions.create(
            # model="gpt-4o-mini",
            # model="grok-3",
            # model="claude-3-7-sonnet-20250219",
            # model="gpt-4o-2024-11-20",
            # model="DeepSeek-R1",
            # model="llama-3.3-70b-instruct",

            # model="DeepSeek-V3",
            # model="Doubao-1.5-pro-32k",
            # model="ERNIE-4.0-8K",
            # model="gemini-2.5-pro-exp-03-25",
            model="qwen/qwq-32b",
            messages=[
                {"role": "system", "content": Prompt.mips_p3_real()},  
                {"role": "user", "content": content}
            ],
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            stream=False
        )


        result = {
            "content": response.choices[0].message.content,
            "model": response.model,
            "finish_reason": response.choices[0].finish_reason,
            "prompt_tokens": response.usage.prompt_tokens,
            "completion_tokens": response.usage.completion_tokens,
            "total_tokens": response.usage.total_tokens
        }
        return result["content"]

    def _get_system_prompt(self):
        """
        ystem Prompt
        :return:
        """

        return """
        """

    def _get_eval_prompt(self):
        """
        Eval Prompt
        :return:
        """
        return """
Task Description:
Hello! Please summarize the provided evaluation results. 
If the content you receive is consistent, return “True”; otherwise, return “False”. 
Please strictly follow the requirement to output a boolean value.
---
EXAMPLE_INPUT:
(Some analysis steps ...)
Conclusion:
The axioms lead to a consistent reasoning structure, as there is no established disjoint relationship between GroceryProduce and RootVegetable that would create a conflict with Turnip being a subclass of both. Therefore, the axiom set is consistent.
- Output: True

EXAMPLE_INPUT:
(Some analysis steps ...)
Conclusion:
The axioms lead to a logical inconsistency because CHROMOSOMALABERRATION is inferred to be a subclass of both DESCRIPTIONPACKAGE and EXPERIMENTPACKAGE, which are explicitly defined as disjoint classes in axiom [8].
- Output: False
---
Do not return any other words, only True or False.
"""

    def eval_process(self, content):
        """
        :param content: content to be dealt with
        :return: response
        """
        response = self.client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": self._get_eval_prompt()},
                {"role": "user", "content": content}
            ],
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            stream=False
        )

        result = {
            "content": response.choices[0].message.content,
            "model": response.model,
            "finish_reason": response.choices[0].finish_reason,
            "prompt_tokens": response.usage.prompt_tokens,
            "completion_tokens": response.usage.completion_tokens,
            "total_tokens": response.usage.total_tokens
        }
        return result["content"]