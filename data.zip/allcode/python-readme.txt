Environment Requirements
•	Python 3.x
•	openai library
•	A valid API key

*************************************

Main Files
1.	LLM_InconsistentDec.py: Core class implementation, including LLM call logic.
2.	main_InconsistentDec.py: Main program, processes input files and outputs results.
3.	prompts.py: Contains system prompt templates.

**************************************
Usage Instructions：

1. Prepare Data Files
Data files should include ontology axiom sets starting with "MIPS <". Each axiom set can contain multiple lines. (When running MIS files, change "MIPS <" to "MIS <").

2. Configure API Key
In LLM_InconsistentDec.py, configure your API key and base URL:
self.client = OpenAI(
    api_key="your-api-key",
    base_url="your-base-url"
)

3. Select Model
In the llm method of LLM_InconsistentDec.py, uncomment the model you wish to use:
model="qwen/qwq-32b",  # Other selectable models include gpt-4o-mini, grok-3, etc.

4. Run Analysis

In main_InconsistentDec.py:
1）	Set the file paths to be analyzed:
   pattern3_file_path = [
       "./data/negative_exps/mips_pattern3_neg.txt",
       "./data/no_red_pos_exps/mips_pattern3.txt",
   ]
   
2）Choose the model name (used for output file naming):
   model_name = "qwq-32b"
   
3）	Select the type of prompt to use (need to concurrently modify the call code in LLM_InconsistentDec.py and the corresponding prompts in prompts.py):
   task = "prompt2"

   
Results will be saved in the directory ./output/InconsistencyDetect/{model_name}/{task}/:
•	*_pred_result.txt: Contains detailed analysis results of the LLM.
•	*_pred_labels.txt: Contains consistency judgment results (True/False) for each axiom set.


Notes
•	Ensure the prompts.py file exists and contains the referenced prompt methods.
•	API calls might incur costs, so be mindful of the usage.
