

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.io.StringDocumentSource;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.reasoner.Node;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Set;
import java.util.Vector;

public class ConflictSampleChecker {
	
	static String prefix = "MIPS";

    public static void main(String[] args) {
        String fileName = "data/llm-mips/mis_pattern1_redundant.txt";
        if(fileName.contains("mis_")){
        	prefix = "MIS";
        }

        Vector<Vector<String>> allMips = new Vector<>();

        // ---------- 1. Read a local file and obtain mips strings----------
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            Vector<String> mips = null;

            while ((line = br.readLine()) != null) {
                if (line.startsWith(prefix)) { 
                    if (mips != null && !mips.isEmpty()) {
                        allMips.add(mips);
                    }
                    mips = new Vector<>();
                } else if (mips != null && line.startsWith("  [")) {
                    mips.add(removeLineLabel(line));
                } else if (line.trim().isEmpty()) {
                    if (mips != null && !mips.isEmpty()) {
                        allMips.add(mips);
                        mips = null;
                    }
                }
            }
            if (mips != null && !mips.isEmpty()) {
                allMips.add(mips);
            }
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        System.out.println("Total: " + allMips.size() + "  MIPS / MIS\n");

        // ---------- 2. Check each MIPS or MIS ----------
        OWLReasonerFactory reasonerFactory =
                new org.semanticweb.HermiT.Reasoner.ReasonerFactory();

        for (int i = 0; i < allMips.size(); i++) {
            Vector<String> mips = allMips.get(i);
            System.out.println("================ MIPS  " + (i + 1) + " ================");

            // 2.1 Construct an ontology
            OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
            OWLOntology ontology;
            try {
                ontology = manager.createOntology();
                for (String axiomStr : mips) {
                    OWLAxiom axiom = parseAxiom(axiomStr, manager);
                    manager.addAxiom(ontology, axiom);
                }
            } catch (Exception e) {
                System.err.println("Failed to parse: " + e.getMessage());
                System.out.println();
                continue;
            }

            // 2.2 Output all axioms in the ontology
            System.out.println("--- Axioms in the ontology ---");
            Set<OWLAxiom> axiomSet = ontology.getAxioms();
            if (axiomSet.isEmpty()) {
                System.out.println("(No axioms)");
            } else {
                for (OWLAxiom ax : axiomSet) {
                    System.out.println(ax);
                }
            }

            // 2.3 Output the number of classes in the ontology
            Set<OWLClass> classes = ontology.getClassesInSignature();
            System.out.println("Classes : " + classes.size());

            // 2.4 Computed unsatisfiable classes using a DL reasoner
            System.out.println("--- Inconsistency or unsatifiability checking ---");
            OWLReasoner reasoner = reasonerFactory.createReasoner(ontology);
            try {
                boolean consistent = reasoner.isConsistent();
                if (!consistent) {
                    System.out.println("It is inconsistent.");
                } else {
                    Node<OWLClass> unsatNode = reasoner.getUnsatisfiableClasses();
                    boolean hasRealUnsat = false;

                    for (OWLClass cls : unsatNode.getEntities()) {
                        if (!cls.isOWLNothing()) {
                            System.out.println("Unsatifiable class: " + cls);
                            hasRealUnsat = true;
                        }
                    }
                    if (!hasRealUnsat) {
                        System.out.println("No unsatisfiable classes.");
                    }
                }
            } catch (Exception e) {
                System.err.println("Failed to do reasoning: " + e.getMessage());
            } finally {
                reasoner.dispose();
            }

            manager.removeOntology(ontology);
            System.out.println();
        }
    }

    /**
     * Transfer an axiom string to OWLAxiom。
     */
    private static OWLAxiom parseAxiom(String axiomStr, OWLOntologyManager manager)
            throws OWLOntologyCreationException {
        String wrapped = "Ontology(\n" + axiomStr + "\n)";
        StringDocumentSource source = new StringDocumentSource(wrapped);

        OWLOntology tempOnt = manager.loadOntologyFromOntologyDocument(source);

        Set<OWLAxiom> axioms = tempOnt.getAxioms();
        if (axioms.isEmpty()) {
            manager.removeOntology(tempOnt);
            throw new IllegalArgumentException("Failed to parse an axiom: " + axiomStr);
        }

        OWLAxiom result = axioms.iterator().next();
        manager.removeOntology(tempOnt);
        return result;
    }

    /**
     * Remove the label of a line: "  [8] SubClassOf(...)" -> "SubClassOf(...)"
     */
    private static String removeLineLabel(String line) {
        String trimmed = line.trim();
        if (trimmed.startsWith("[")) {
            int endIdx = trimmed.indexOf(']');
            if (endIdx != -1) {
                return trimmed.substring(endIdx + 1).trim();
            }
        }
        return trimmed;
    }
}