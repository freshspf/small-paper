package conflict;

import java.util.HashMap;
import java.util.HashSet;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLOntology;

import com.clarkparsia.owlapiv3.OWL;

import edu.njupt.radon.debug.incoherence.RadonDebug;
import edu.njupt.radon.debug.incoherence.blackbox.BlackboxDebug;
import edu.njupt.radon.debug.incoherence.blackbox.ComputeMIPS;
import edu.njupt.radon.debug.inconsistency.ComputeMIS;
import edu.njupt.radon.utils.io.MyPrinter;
import edu.njupt.radon.utils.reasoning.ReasoningTools;

public class ConflictPositiveRedundant {
	
	boolean dealwithInconsistent = true;

	public static void main(String[] args) throws Exception {
		// The name of the ontology to be considered
		String ontoName = "buggyPolicy-inc";
		// The path of the ontology
		String ontoPath = "file:onto/"+ontoName+".owl"; 
		// The maximal number of axioms to be generated for a positive sample with redundant axioms
		int axNum = 15;  
		// Set true if the ontology is inconsistent, false otherwise.
		boolean dealwithInconsistent = true; 
		
		
		OWLOntology ont = OWL.manager.loadOntologyFromOntologyDocument(IRI.create(ontoPath));
        System.out.println(" original onto size: "+ont.getLogicalAxiomCount());
        
        ConflictPositiveRedundant pos = new ConflictPositiveRedundant(true);
        HashSet<HashSet<OWLAxiom>> allConflicts = null;
        if(dealwithInconsistent) {
        	allConflicts = pos.computeAllMIS(ont);
        } else {
        	allConflicts = pos.computeAllMIPS(ont);
        }
        pos.producePositiveRedSample(ont, allConflicts, axNum);

	}
	
	public ConflictPositiveRedundant(boolean dealwithInconsistent) {
		this.dealwithInconsistent = dealwithInconsistent;
	}
	
	public HashSet<HashSet<OWLAxiom>> computeAllMIPS(OWLOntology ont) throws Exception {			
		RadonDebug debug = new BlackboxDebug(ont);
		HashMap<OWLClass, HashSet<HashSet<OWLAxiom>>> allMUPS = debug.getMUPS();	
		HashSet<HashSet<OWLAxiom>> mips = ComputeMIPS.computeMIPS(allMUPS);
		System.out.println("************* MIPS ***********");
		MyPrinter.printMultiSets(mips, null);
		return mips;
	}
	
        // Compute all minimal inconsistent sub-ontologies (i.e., MIS) for a given ontology
	public HashSet<HashSet<OWLAxiom>> computeAllMIS(OWLOntology ont) throws Exception {		
		ComputeMIS debug = new ComputeMIS();
		HashSet<HashSet<OWLAxiom>> mis = debug.getAllMIS(ont);
		
		System.out.println("************* MIS ***********");
		MyPrinter.printMultiSets(mis, null);
		return mis;
	}
	
        // Construct a positive sample with redundant axioms
	public HashSet<OWLAxiom> producePositiveRedSample(OWLOntology ont, 
			HashSet<HashSet<OWLAxiom>> allMIPS, int axNum) {
		
		HashSet<OWLAxiom> oneMIPS = null; // the MIPS that should be included in the output
		OWLAxiom oneAxiom = null;		
		HashSet<OWLAxiom> ignoreAxioms = new HashSet<OWLAxiom>();
		
                // Break the reasoning chains for all MIPS except the selected one (i.e., oneMIPS)
                // That is, choose one axiom from each such MIPS and all selected axioms are stored in ignoreAxioms
		for(HashSet<OWLAxiom> aMIPS : allMIPS) {
			if(oneMIPS == null) {
				oneMIPS = new HashSet<OWLAxiom>(aMIPS);
				oneAxiom = oneMIPS.iterator().next();
				ignoreAxioms.addAll(aMIPS);
				continue;
			}
			
			OWLAxiom ax = aMIPS.iterator().next();
			ignoreAxioms.add(ax);
		}
		
		HashSet<OWLAxiom> axiomsLeft =  new HashSet<OWLAxiom>(ont.getLogicalAxioms());
		axiomsLeft.removeAll(ignoreAxioms);
		HashSet<OWLAxiom> posRedSample = new HashSet<OWLAxiom>(oneMIPS);
		posRedSample.remove(oneAxiom);
		for(OWLAxiom a : axiomsLeft) {
			posRedSample.add(a);		
			if(dealwithInconsistent && !ReasoningTools.isConsistent(posRedSample)) {
				posRedSample.remove(a);
			} else if(!dealwithInconsistent && !ReasoningTools.isCoherent(posRedSample)) {
				posRedSample.remove(a);
			}
			if(posRedSample.size() >= axNum-1) {
				break;
			}
		}
		posRedSample.add(oneAxiom);
		
		int i = 0;
		for(OWLAxiom a: posRedSample) {
			System.out.println((i++)+"> "+a.toString());
		}
		return posRedSample;
	}

}
