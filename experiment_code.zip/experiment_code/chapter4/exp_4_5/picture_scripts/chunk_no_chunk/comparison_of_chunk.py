from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager


BASE_DIR = Path("/Users/ning/Developer/project26/exps/chapter3v0323/chapter4/exp_4_5")
OUTPUT_DIR = BASE_DIR / "picture_result/chunk_no_chunk"
OUTPUT_PATH = OUTPUT_DIR / "comparison_of_chunk.png"

DOMAINS = ["Geography", "Medical", "Transportation"]
NO_CHUNK = [7.6, 6.4, 11.2]
CHUNK = [136.6, 121.4, 213.2]


def configure_font() -> None:
    candidates = [
        "PingFang SC",
        "Hiragino Sans GB",
        "STHeiti",
        "Heiti SC",
        "Arial Unicode MS",
    ]
    available_fonts = {font.name for font in font_manager.fontManager.ttflist}

    for font_name in candidates:
        if font_name in available_fonts:
            plt.rcParams["font.sans-serif"] = [font_name]
            break
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans"]

    plt.rcParams["axes.unicode_minus"] = False


def main() -> None:
    configure_font()

    x = np.arange(len(DOMAINS))
    width = 0.34

    fig, ax = plt.subplots(figsize=(9.8, 5.8), dpi=300)

    no_chunk_bars = ax.bar(
        x - width / 2,
        NO_CHUNK,
        width=width,
        label="No-chunk",
        color="#8FA8A1",
        edgecolor="#4F5B58",
        linewidth=0.8,
    )
    chunk_bars = ax.bar(
        x + width / 2,
        CHUNK,
        width=width,
        label="Chunk",
        color="#D8C3A5",
        edgecolor="#8C7B6A",
        linewidth=0.8,
    )

    ax.set_xticks(x)
    ax.set_xticklabels(DOMAINS)
    ax.set_ylabel("Effective Axioms", fontsize=13)
    ax.set_xlabel("Domain", fontsize=13)
    ax.set_title("Comparison of Effective Axioms under Different Input Strategies", fontsize=15, pad=12)
    ax.tick_params(axis="x", labelsize=12)
    ax.tick_params(axis="y", labelsize=12)
    ax.grid(axis="y", linestyle="--", linewidth=0.6, alpha=0.35, color="#B8BDC6")
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color("#888888")
    ax.spines["bottom"].set_color("#888888")
    ax.legend(frameon=False, fontsize=11)

    upper = max(CHUNK) * 1.18
    ax.set_ylim(0, upper)

    for bars in (no_chunk_bars, chunk_bars):
        for bar in bars:
            value = bar.get_height()
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                value + upper * 0.012,
                f"{value:.1f}",
                ha="center",
                va="bottom",
                fontsize=10,
                color="#444444",
            )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(OUTPUT_PATH, dpi=300, bbox_inches="tight")
    plt.close(fig)

    print(f"Saved figure to: {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
